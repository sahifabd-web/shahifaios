#!/bin/bash

# Shahifa Unlocker iOS Tools - Quick Reference
# Run: cat QUICKSTART.md

cat << 'EOF'

╔══════════════════════════════════════════════════════════════════════╗
║                                                                      ║
║          🔧 SHAHIFA UNLOCKER iOS TOOLS - QUICK START                ║
║                                                                      ║
║              Professional macOS Desktop Application                  ║
║                                                                      ║
╚══════════════════════════════════════════════════════════════════════╝


📋 REQUIREMENTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✓ macOS 10.13 or later
✓ Node.js 14+ (install from https://nodejs.org/)
✓ npm 6+ (comes with Node.js)
✓ Internet connection


🚀 INSTALLATION (3 COMMANDS)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. Navigate to the application directory:
   $ cd /var/www/shahifa.com/shahifa-unlocker-app

2. Install dependencies:
   $ npm install

3. Run the application:
   $ npm start
   or
   $ ./setup.sh


✨ LOGIN
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Username:  Your shahifa.com username
Password:  Your shahifa.com password
2FA Code:  6-digit code (if enabled)

Remember Me: Check to stay logged in


🎨 UI FEATURES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Professional Red & Silver Theme:
- Primary Red:     #C71C1C
- Silver:          #E8E8E8
- Clean design
- Responsive layout
- macOS native feel


📊 DASHBOARD SECTIONS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Overview      → Statistics & quick actions
Services      → Available iOS repair tools
Devices       → Connected iOS devices
Wallet        → Account balance & credits
Subscription  → Current plan & upgrades
History       → Operation logs
Profile       → Account settings
Security      → 2FA & password management


🔧 AVAILABLE SERVICES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔓 iCloud Bypass       → iOS 12-26.1, A5-A17
📱 Device Detection    → Automatic identification
⚙️  Bypass Tools        → Path A (checkm8) & Path B
📊 Analytics           → Operation reports
🛡️  Security Suite     → Encrypted operations
🌐 Cloud Sync         → Multi-device synchronization


⌨️  KEYBOARD SHORTCUTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Cmd+Q          → Quit application
Cmd+Shift+I    → Open Dev Tools (development mode)
Cmd+,          → Application settings
Cmd+R          → Refresh page


🔐 SECURITY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✓ JWT authentication
✓ Secure token storage
✓ HTTPS only communication
✓ Context isolation
✓ No password caching


🏗️  BUILD & DEPLOYMENT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Create DMG Installer:
$ npm run build-mac

Output: dist/Shahifa Unlocker iOS Tools-1.0.0.dmg


🐛 TROUBLESHOOTING
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

App won't start:
  $ rm -rf node_modules package-lock.json
  $ npm install
  $ npm start

Login fails:
  ✓ Check internet connection
  ✓ Verify username/password
  ✓ Ensure shahifa.com account is active

API connection error:
  $ curl https://shahifa.com/api/health


📁 FILE STRUCTURE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

shahifa-unlocker-app/
├── src/main.js               → Main Electron process
├── public/
│   ├── index.html            → UI interface
│   ├── styles/main.css       → Professional styling
│   └── js/main.js            → Application logic
├── package.json              → Dependencies
├── setup.sh                  → Quick setup
├── README.md                 → Documentation
└── SETUP_GUIDE.md           → Detailed guide


📞 SUPPORT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Documentation:  SETUP_GUIDE.md, README.md
Issues:         support@shahifa.com
Website:        https://shahifa.com
API Status:     https://shahifa.com/api/health


📦 SYSTEM REQUIREMENTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Memory:     2GB minimum, 4GB recommended
Disk Space: 500MB for installation
Bandwidth:  For API communication with shahifa.com
Processor:  Intel or Apple Silicon


🌟 FEATURES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ Secure JWT authentication
✅ Professional UI with red & silver theme
✅ Full dashboard with statistics
✅ Wallet management
✅ Subscription plans
✅ Device management
✅ Operation history
✅ Security settings
✅ Cloud synchronization


💡 TIPS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

• Check "Remember me" for persistent login
• Enable 2FA in security settings for extra protection
• Monitor wallet balance for sufficient credits
• Review history for past operations
• Upgrade subscription for unlimited operations


🔗 QUICK LINKS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Website:        https://shahifa.com
Backend:        https://shahifa.com/api
Documentation:  ./README.md
Setup Guide:    ./SETUP_GUIDE.md
Deployment:     ./DEPLOYMENT.md


════════════════════════════════════════════════════════════════════════

Need help? Run: cat SETUP_GUIDE.md
For development: npm run dev
For production: npm run build-mac

Happy coding! 🚀

════════════════════════════════════════════════════════════════════════

EOF
