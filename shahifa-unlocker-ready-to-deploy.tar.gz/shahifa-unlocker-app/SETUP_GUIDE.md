# Shahifa Unlocker iOS Tools - Setup Guide

Complete step-by-step guide to set up and run the professional macOS desktop application.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Installation](#installation)
3. [Configuration](#configuration)
4. [Running the Application](#running-the-application)
5. [Building for macOS](#building-for-macos)
6. [Troubleshooting](#troubleshooting)

## Prerequisites

Before you begin, ensure you have:

### System Requirements
- **macOS** 10.13 Mojave or later
- **Apple Silicon (M1/M2/M3)** or **Intel** processor
- At least 2GB free disk space
- Internet connection (for authentication)

### Software Requirements
- **Node.js** v14.0.0 or later (recommended: v18+)
- **npm** v6.0.0 or later
- **Git** (optional, for version control)
- Xcode Command Line Tools (optional, for building)

### Installation Check

```bash
# Check Node.js
node --version  # Should show v14.0.0 or higher

# Check npm
npm --version   # Should show v6.0.0 or higher
```

If you don't have Node.js installed, download from: https://nodejs.org/

## Installation

### Step 1: Navigate to Application Directory

```bash
cd /var/www/shahifa.com/shahifa-unlocker-app
```

### Step 2: Install Dependencies

```bash
npm install
```

This will install:
- **electron** - Desktop application framework
- **axios** - HTTP client for API calls
- **electron-builder** - Package manager
- Other supporting libraries

**Expected output:**
```
added 200+ packages in 45s
```

### Step 3: Verify Installation

```bash
npm list | head -20
```

You should see the list of installed packages without errors.

## Configuration

### Backend API Setup

The application connects to the shahifa.com backend for authentication.

#### Check Current Configuration

```bash
grep "API_BASE_URL" src/main.js
```

Current: `https://shahifa.com/api`

#### Update API URL (if needed)

Edit `src/main.js`:

```javascript
// Line 10 - Current configuration
const API_BASE_URL = 'https://shahifa.com/api';

// Change to your backend URL if different
const API_BASE_URL = 'https://your-domain.com/api';
```

### Environment Configuration (Optional)

Create `.env` file for advanced configuration:

```bash
cat > .env << EOF
API_BASE_URL=https://shahifa.com/api
AUTH_TOKEN_REFRESH=true
SECURE_STORAGE=true
LOG_LEVEL=info
EOF
```

## Running the Application

### Method 1: Using Setup Script (Recommended)

```bash
./setup.sh
```

This script will:
✓ Check Node.js installation
✓ Verify npm version
✓ Install dependencies
✓ Validate configuration
✓ Launch the application

### Method 2: Manual Launch

**Development Mode:**
```bash
npm start
```

**Development Mode with Dev Tools:**
```bash
npm run dev
```

The application window should appear with the login screen.

### First Login

1. Enter your **shahifa.com** username
2. Enter your **password**
3. If 2FA is enabled, enter your **6-digit code**
4. Click **Sign In**

**Successful login indicators:**
- ✓ Welcome message shows your username
- ✓ Dashboard loads with your account stats
- ✓ Wallet balance displays

## Building for macOS

### Create DMG Installer

```bash
npm run build-mac
```

**Output:**
- `dist/Shahifa Unlocker iOS Tools-1.0.0.dmg` - Installer for distribution
- `dist/Shahifa Unlocker iOS Tools-1.0.0.zip` - Portable version

### Create Standard Package

```bash
npm run dist
```

**Output files in `dist/` directory:**
- DMG installer
- ZIP archive
- App bundle

### Code Signing (Optional)

For Mac App Store or developer signing:

```bash
# Requires Apple Developer Certificate
codesign --deep --force --verify --verbose \
  --sign "Developer ID Application: Your Name (XXXXXXXXXX)" \
  dist/Shahifa\ Unlocker\ iOS\ Tools.app
```

### Build Sizes

| Format | Size | Notes |
|--------|------|-------|
| DMG | ~150MB | Installer |
| ZIP | ~140MB | Portable |
| App Bundle | ~500MB | Uncompressed |

## Application Features

### Login Screen
- Professional red and silver design
- Secure credential entry
- 2FA support
- Remember me option
- Error handling with clear messages

### Dashboard Features

#### Overview Tab
- Quick statistics dashboard
- Connected devices count
- Operation history
- Quick action buttons

#### Services Tab
- iCloud Bypass (iOS 12-26.1)
- Device Detection
- Advanced Bypass Tools
- Analytics & Reporting
- Security Suite
- Cloud Synchronization

#### Devices Tab
- Connected iOS device list
- Device details and specifications
- Operation management

#### Wallet Tab
- Account balance display
- Monthly usage tracking
- Transaction history
- Add credit option

#### Subscription Tab
- Current plan details
- Available upgrade options
- Plan comparison
- Billing information

#### History Tab
- Operation log
- Filter by type
- Export functionality
- Status tracking

## File Structure

```
shahifa-unlocker-app/
├── src/
│   ├── main.js              # Electron main process
│   └── preload.js           # Secure IPC bridge
├── public/
│   ├── index.html           # Main UI
│   ├── styles/
│   │   └── main.css         # Styling
│   └── js/
│       └── main.js          # Frontend logic
├── assets/
│   └── icons/               # Application icons
├── package.json             # Dependencies
├── README.md                # Documentation
├── SETUP_GUIDE.md          # This file
└── setup.sh                # Quick setup script
```

## Troubleshooting

### Issue: "Node.js not found" Error

**Solution:**
```bash
# Check installation
which node

# If not found, install from nodejs.org
# Then close and reopen terminal
```

### Issue: npm install Fails

**Solution:**
```bash
# Clear npm cache
npm cache clean --force

# Delete node_modules
rm -rf node_modules package-lock.json

# Reinstall
npm install
```

### Issue: Application Won't Start

**Solution:**
```bash
# Check for errors
npm start

# If that fails, try:
npm run dev

# View logs
cat ~/.config/Shahifa\ Unlocker\ iOS\ Tools/logs/main.log
```

### Issue: "API Connection Failed"

**Solution:**
1. Check internet connection
2. Verify API URL in `src/main.js`
3. Test backend:
   ```bash
   curl https://shahifa.com/api/health
   ```
4. Check firewall settings

### Issue: Login Always Returns "Invalid Credentials"

**Solution:**
1. Verify username and password on shahifa.com
2. Check 2FA code if enabled
3. Ensure account is active
4. Try resetting password on website

### Issue: High CPU Usage

**Solution:**
```bash
# Restart application
# Check Activity Monitor (Cmd+Space → Activity Monitor)
# Kill and restart: npm start
```

### Issue: Application Crashes on Startup

**Solution:**
```bash
# Enable debug mode
npm run dev

# Check console output for errors

# Clear application cache
rm -rf ~/Library/Application\ Support/Shahifa\ Unlocker\ iOS\ Tools/

# Reinstall
npm install
npm start
```

## Performance Optimization

### For Slow Systems

Reduce animations in `public/styles/main.css`:
```css
/* Reduce animation duration */
animation-duration: 0.1s !important;
transition-duration: 0.1s !important;
```

### For Low Memory

Limit cached data in `public/js/main.js`:
```javascript
// Reduce data cache size
const MAX_CACHE_SIZE = 50; // items
```

## Security Notes

1. **Credentials**: Never shared between components
2. **Tokens**: Stored in secure Electron storage
3. **API**: All communication over HTTPS
4. **Context Isolation**: Enabled for IPC security

## Support & Resources

### Documentation
- [README.md](./README.md) - Feature overview
- [API Reference](../server/README.md) - Backend API docs
- [Electron Documentation](https://www.electronjs.org/docs)

### Contact
- **Support**: support@shahifa.com
- **Issues**: GitHub issues or support portal
- **Feedback**: feedback@shahifa.com

### Community
- Discussion forums
- Slack channel
- User groups

## Advanced Topics

### Development with Hot Reload

```bash
# Terminal 1: Start webpack dev server
npm run dev

# Terminal 2: Start Electron in watch mode
electron . --dev
```

### Debugging

Use Chrome DevTools:
- Press: `Ctrl+Shift+I` (Windows) or `Cmd+Option+I` (macOS)

### Custom Builds

```bash
# Build with custom signing
npm run build-mac -- --sign "Developer ID"

# Create universal binary (Apple Silicon + Intel)
npm run build-mac -- --universal
```

## Next Steps

1. ✅ Complete setup following this guide
2. 📝 Create shahifa.com account
3. 🔑 Configure API access
4. 🚀 Launch the application
5. 📱 Connect your first iOS device
6. ⚙️ Configure service preferences

---

**Version**: 1.0.0  
**Last Updated**: August 2024  
**Maintained By**: Shahifa Technologies
