// Main application controller
class SahifaUnlocker {
    constructor() {
        this.currentUser = null;
        this.authToken = null;
        this.init();
    }

    async init() {
        // Check if user is already logged in
        this.setupEventListeners();
        const token = localStorage.getItem('authToken');
        if (token) {
            this.authToken = token;
            await this.loadDashboard();
        } else {
            this.showLoginScreen();
        }
    }

    setupEventListeners() {
        // Login form
        const loginForm = document.getElementById('loginForm');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => this.handleLogin(e));
        }

        // Toggle password visibility
        const toggleBtn = document.getElementById('togglePassword');
        if (toggleBtn) {
            toggleBtn.addEventListener('click', () => this.togglePasswordVisibility());
        }

        // Navigation links
        document.querySelectorAll('[data-section]').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = e.currentTarget.dataset.section;
                this.switchSection(section);
            });
        });

        // User menu
        const userMenuBtn = document.getElementById('userMenuBtn');
        const userDropdown = document.getElementById('userDropdown');
        if (userMenuBtn) {
            userMenuBtn.addEventListener('click', () => {
                userDropdown.style.display = userDropdown.style.display === 'none' ? 'block' : 'none';
            });
        }

        // Logout
        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.logout();
            });
        }
    }

    togglePasswordVisibility() {
        const passwordInput = document.getElementById('password');
        const toggleBtn = document.getElementById('togglePassword');
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            toggleBtn.textContent = '🙈';
        } else {
            passwordInput.type = 'password';
            toggleBtn.textContent = '👁️';
        }
    }

    async handleLogin(e) {
        e.preventDefault();
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const mfaCode = document.getElementById('mfaCode').value;
        const loginBtn = document.getElementById('loginBtn');
        const spinner = document.getElementById('spinner');
        const errorBanner = document.getElementById('errorBanner');

        // Validate inputs
        if (!username || !password) {
            this.showError('Please enter both username and password');
            return;
        }

        // Show loading state
        loginBtn.disabled = true;
        spinner.style.display = 'inline-block';
        errorBanner.style.display = 'none';

        try {
            // Call Electron API
            const result = await window.electronAPI.login(username, password, mfaCode);

            if (result.success) {
                this.authToken = result.data.accessToken;
                localStorage.setItem('authToken', result.data.accessToken);
                localStorage.setItem('refreshToken', result.data.refreshToken);
                localStorage.setItem('user', JSON.stringify(result.data.user));
                this.currentUser = result.data.user;
                
                // Clear form
                document.getElementById('loginForm').reset();
                
                // Load dashboard
                await this.loadDashboard();
            } else if (result.data && result.data.mfaRequired) {
                // Show MFA input
                document.getElementById('mfaContainer').style.display = 'block';
                this.showError('Two-factor code required');
            } else {
                this.showError(result.error || 'Login failed');
            }
        } catch (error) {
            this.showError('Connection error: ' + error.message);
        } finally {
            loginBtn.disabled = false;
            spinner.style.display = 'none';
        }
    }

    async loadDashboard() {
        this.showDashboard();
        await this.loadUserData();
    }

    showLoginScreen() {
        document.getElementById('loginScreen').style.display = 'flex';
        document.getElementById('dashboardScreen').style.display = 'none';
    }

    showDashboard() {
        document.getElementById('loginScreen').style.display = 'none';
        document.getElementById('dashboardScreen').style.display = 'flex';
    }

    async loadUserData() {
        try {
            const result = await window.electronAPI.getUser();
            if (result.success) {
                this.currentUser = result.user;
                this.updateUserUI();
                await this.loadWalletData();
                await this.loadSubscriptionData();
            }
        } catch (error) {
            console.error('Error loading user data:', error);
        }
    }

    updateUserUI() {
        if (this.currentUser) {
            const userAvatar = document.getElementById('userAvatar');
            const userName = document.getElementById('userName');
            
            userAvatar.textContent = this.currentUser.username.charAt(0).toUpperCase();
            userName.textContent = this.currentUser.username;

            // Update profile fields
            document.getElementById('profileUsername').value = this.currentUser.username;
            document.getElementById('profileEmail').value = this.currentUser.email || 'N/A';
            document.getElementById('profileStatus').value = this.currentUser.isActive ? 'Active' : 'Inactive';
        }
    }

    async loadWalletData() {
        try {
            const result = await window.electronAPI.getWallet();
            if (result.success && result.data) {
                const balance = result.data.balance || 0;
                document.getElementById('walletBalance').textContent = '$' + balance.toFixed(2);
                document.getElementById('totalBalance').textContent = '$' + balance.toFixed(2);
                document.getElementById('monthlyUsage').textContent = '$' + (result.data.monthlyUsage || 0).toFixed(2);
            }
        } catch (error) {
            console.error('Error loading wallet data:', error);
        }
    }

    async loadSubscriptionData() {
        try {
            const result = await window.electronAPI.getSubscription();
            if (result.success && result.data) {
                const status = result.data.plan || 'Free';
                document.getElementById('subscriptionStatus').textContent = status;
            }
        } catch (error) {
            console.error('Error loading subscription data:', error);
        }
    }

    switchSection(section) {
        // Hide all sections
        document.querySelectorAll('.content-section').forEach(s => {
            s.classList.remove('active');
            s.style.display = 'none';
        });

        // Show selected section
        const selectedSection = document.getElementById(section);
        if (selectedSection) {
            selectedSection.classList.add('active');
            selectedSection.style.display = 'block';
        }

        // Update navigation
        document.querySelectorAll('[data-section]').forEach(link => {
            link.classList.remove('active');
            if (link.dataset.section === section) {
                link.classList.add('active');
            }
        });
    }

    async logout() {
        try {
            await window.electronAPI.logout();
            localStorage.removeItem('authToken');
            localStorage.removeItem('refreshToken');
            localStorage.removeItem('user');
            this.authToken = null;
            this.currentUser = null;
            this.showLoginScreen();
        } catch (error) {
            console.error('Logout error:', error);
        }
    }

    showError(message) {
        const errorBanner = document.getElementById('errorBanner');
        errorBanner.textContent = message;
        errorBanner.style.display = 'block';
    }
}

// Initialize app when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.app = new SahifaUnlocker();
});
