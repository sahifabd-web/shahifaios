#!/bin/bash

# Shahifa Unlocker iOS Tools - GitHub Actions Setup Script
# This script sets up GitHub for building DMG on macOS automatically

echo "🚀 Shahifa Unlocker iOS Tools - GitHub Setup"
echo "=============================================="
echo ""

# Check if git is installed
if ! command -v git &> /dev/null; then
    echo "❌ Git is not installed!"
    echo "Install from: https://git-scm.com/download/linux"
    exit 1
fi

# Check if GitHub CLI is installed
if ! command -v gh &> /dev/null; then
    echo "⚠️  GitHub CLI not found (optional)"
    echo "Install from: https://cli.github.com/"
fi

echo "✅ Prerequisites OK"
echo ""

# Initialize git
echo "📝 Initializing Git repository..."
git init

echo "👤 Setting up Git config..."
read -p "Enter your email: " email
read -p "Enter your name: " name

git config user.email "$email"
git config user.name "$name"

echo ""
echo "📦 Adding all files..."
git add .

echo "💾 Creating initial commit..."
git commit -m "Initial commit: Shahifa Unlocker iOS Tools v1.0.0"

echo ""
echo "🌐 Ready to push to GitHub!"
echo ""
echo "Next steps:"
echo "1. Create repository at: https://github.com/new"
echo "2. Copy the repository URL"
echo "3. Run: git remote add origin <YOUR_REPO_URL>"
echo "4. Run: git branch -M main"
echo "5. Run: git push -u origin main"
echo ""
echo "After pushing:"
echo "1. Go to Actions tab in GitHub"
echo "2. Click 'Build macOS DMG' workflow"
echo "3. Click 'Run workflow' button"
echo "4. Wait 5-10 minutes for build"
echo "5. Download DMG from artifacts"
echo ""
echo "✨ Setup complete!"
