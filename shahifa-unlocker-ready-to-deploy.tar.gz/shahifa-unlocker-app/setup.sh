#!/bin/bash

# Shahifa Unlocker iOS Tools - Quick Setup Script
# This script sets up and launches the macOS application

set -e

echo "╔════════════════════════════════════════════════════════════════╗"
echo "║      Shahifa Unlocker iOS Tools - Setup & Launch             ║"
echo "╚════════════════════════════════════════════════════════════════╝"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if Node.js is installed
echo -e "\n${YELLOW}Checking prerequisites...${NC}"
if ! command -v node &> /dev/null; then
    echo -e "${RED}✗ Node.js is not installed${NC}"
    echo "Please install Node.js from https://nodejs.org/"
    exit 1
fi
echo -e "${GREEN}✓ Node.js $(node --version)${NC}"

if ! command -v npm &> /dev/null; then
    echo -e "${RED}✗ npm is not installed${NC}"
    exit 1
fi
echo -e "${GREEN}✓ npm $(npm --version)${NC}"

# Navigate to app directory
APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$APP_DIR"
echo -e "${GREEN}✓ App directory: $APP_DIR${NC}"

# Install dependencies
echo -e "\n${YELLOW}Installing dependencies...${NC}"
if [ ! -d "node_modules" ]; then
    npm install
    echo -e "${GREEN}✓ Dependencies installed${NC}"
else
    echo -e "${GREEN}✓ Dependencies already installed${NC}"
fi

# Check configuration
echo -e "\n${YELLOW}Checking configuration...${NC}"
if grep -q "https://shahifa.com/api" src/main.js; then
    echo -e "${GREEN}✓ API configured correctly${NC}"
else
    echo -e "${YELLOW}⚠ API configuration may need adjustment${NC}"
fi

# Launch application
echo -e "\n${YELLOW}Launching application...${NC}"
npm start

echo -e "\n${GREEN}Application started!${NC}"
