# Shahifa Unlocker iOS Tools

Professional macOS desktop application for iOS device management and repair. Login and Dashboard UI integrated with shahifa.com backend for secure authentication and operation management.

## Features

- 🔐 **Secure Authentication** - JWT-based login with backend database integration
- 📱 **Device Management** - Connect and manage iOS devices (A5-A17 chips)
- ⚡ **Lightning Fast** - Optimized for performance
- 🎨 **Professional UI** - Red and silver themed macOS native interface
- 💳 **Wallet Management** - Track credits and subscriptions
- 📊 **Dashboard** - Real-time statistics and operation history
- 🛡️ **Enterprise Security** - Bank-grade encryption

## System Requirements

- **macOS** 10.13 or later
- **Node.js** 14+ and npm
- Internet connection for authentication

## Installation

### 1. Clone/Download the Application

```bash
cd /var/www/shahifa.com/shahifa-unlocker-app
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Configure Backend

Edit the API base URL in `src/main.js`:

```javascript
const API_BASE_URL = 'https://shahifa.com/api';
```

Make sure the backend is running at this URL.

### 4. Run the Application

**Development Mode:**
```bash
npm start
```

**With Dev Tools:**
```bash
npm run dev
```

### 5. Build for Distribution

**macOS DMG Installer:**
```bash
npm run build-mac
```

**Distributable Package:**
```bash
npm run dist
```

## Architecture

### Frontend (Electron + JavaScript)

- **Main Process** (`src/main.js`): Manages windows, IPC, and API calls
- **Preload Script** (`src/preload.js`): Secure context bridge
- **UI** (`public/index.html`): Professional login and dashboard interface
- **Styling** (`public/styles/main.css`): Red and silver theme
- **Logic** (`public/js/main.js`): Application state and event handling

### Backend Integration

- **API Base URL**: `https://shahifa.com/api`
- **Authentication**: POST `/auth/login`
- **Wallet**: GET `/my-wallet`
- **Subscription**: GET `/my-subscription`
- **Token Storage**: Secure localStorage with refresh token rotation

## Usage

### Login

1. Open the application
2. Enter your shahifa.com username and password
3. Optionally enable "Remember me"
4. Click "Sign In"

### Dashboard Navigation

- **Overview** - View statistics and quick actions
- **Services** - Available repair and bypass tools
- **Devices** - Connected iOS devices
- **Wallet** - Account balance and transactions
- **Subscription** - Upgrade or change your plan
- **History** - View past operations
- **Profile** - Manage account settings
- **Security** - 2FA and password management

### Available Services

1. **iCloud Bypass** - Remove activation lock (iOS 12-26.1, A5-A17)
2. **Device Detection** - Automatic device identification
3. **Advanced Tools** - Path A (checkm8) and Path B (Session)
4. **Analytics** - Detailed operation reports
5. **Security Suite** - Encrypted operations
6. **Cloud Sync** - Multi-device synchronization

## Configuration

### Environment Variables

Create a `.env` file in the root directory:

```
API_BASE_URL=https://shahifa.com/api
AUTH_TOKEN_REFRESH=true
SECURE_STORAGE=true
LOG_LEVEL=info
```

### Customization

#### Change Application Name
Edit `package.json`:
```json
{
  "productName": "Shahifa Unlocker iOS Tools",
  "build": {
    "appId": "com.shahifa.unlocker.ios.tools"
  }
}
```

#### Change Colors
Edit `public/styles/main.css`:
```css
:root {
    --primary-red: #C71C1C;
    --silver: #E8E8E8;
}
```

#### Custom API Endpoints
Edit `src/main.js`:
```javascript
const API_BASE_URL = 'your-custom-url';
```

## API Endpoints

| Endpoint | Method | Description | Auth |
|----------|--------|-------------|------|
| `/auth/login` | POST | User login | ❌ |
| `/auth/refresh` | POST | Refresh token | ❌ |
| `/auth/logout` | POST | User logout | ✅ |
| `/my-wallet` | GET | User wallet info | ✅ |
| `/my-subscription` | GET | User subscription | ✅ |
| `/subscription-plans` | GET | Available plans | ✅ |

## Data Storage

The application securely stores:

- **Authentication Token** - localStorage (Electron secure storage)
- **Refresh Token** - localStorage with automatic rotation
- **User Profile** - In-memory cache
- **Settings** - Application userData directory

## Security Features

- 🔒 **JWT Authentication** - Secure token-based auth
- 🔄 **Token Rotation** - Automatic refresh token rotation
- 🛡️ **HTTPS Only** - All communication encrypted
- 🔐 **Context Isolation** - Electron IPC security
- 🚫 **CSP Headers** - Content Security Policy
- 📝 **Audit Logging** - Operation tracking

## Troubleshooting

### Login Issues

**Problem**: "Connection error"
- **Solution**: Check internet connection and API URL in `src/main.js`

**Problem**: "Invalid credentials"
- **Solution**: Verify username/password on shahifa.com

**Problem**: "MFA Required"
- **Solution**: Enter your 2FA code when prompted

### Performance Issues

**Problem**: Slow device detection
- **Solution**: Check USB connection and driver installation

**Problem**: Unresponsive UI
- **Solution**: Restart the application

### Data Not Syncing

**Problem**: Wallet/subscription not updating
- **Solution**: 
  1. Logout and login again
  2. Check backend API status
  3. Verify internet connection

## Development

### Adding New Features

1. **Backend Changes**: Modify `/var/www/shahifa.com/server/index.js`
2. **Frontend Changes**: Edit files in `public/`
3. **IPC Handlers**: Add handlers in `src/main.js`
4. **UI Components**: Add sections to `public/index.html`

### Testing

```bash
# Run with dev tools
npm run dev

# Check application logs
open ~/Library/Logs/Shahifa\ Unlocker\ iOS\ Tools/
```

### Building for Release

```bash
# Clean build
rm -rf dist/
npm run build-mac

# Sign the application
codesign --deep --force --verify --verbose --sign "Developer ID Application" dist/Shahifa\ Unlocker\ iOS\ Tools.app
```

## Support

For issues or questions:

1. Check logs in Application menu → View
2. Visit https://shahifa.com/support
3. Contact admin@shahifa.com

## License

Proprietary - Shahifa Technologies © 2024

## Version History

### v1.0.0 (Initial Release)
- Login and authentication
- Dashboard with statistics
- Services management
- Wallet and subscription handling
- User profile management
- Security settings

## Credits

Built with:
- **Electron** - Desktop application framework
- **Node.js** - Backend runtime
- **JavaScript** - Application logic
- **CSS3** - Professional styling

## Roadmap

- [ ] Offline mode support
- [ ] Multi-account switching
- [ ] Dark theme option
- [ ] Apple device pairing
- [ ] Real-time device monitoring
- [ ] Advanced analytics dashboard
- [ ] Custom operation templates
- [ ] Cloud backup integration
