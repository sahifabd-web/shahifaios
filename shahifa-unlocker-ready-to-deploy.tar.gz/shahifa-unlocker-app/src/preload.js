const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  login: (username, password, mfaCode) =>
    ipcRenderer.invoke('login', { username, password, mfaCode }),
  logout: () => ipcRenderer.invoke('logout'),
  getUser: () => ipcRenderer.invoke('get-user'),
  getWallet: () => ipcRenderer.invoke('get-wallet'),
  getSubscription: () => ipcRenderer.invoke('get-subscription'),
  getSubscriptionPlans: () => ipcRenderer.invoke('get-subscription-plans'),
  startDeviceDetection: () => ipcRenderer.invoke('start-device-detection'),
  executeBypass: (deviceId, method) =>
    ipcRenderer.invoke('execute-bypass', { deviceId, method }),
  onDeviceConnected: (callback) =>
    ipcRenderer.on('device-connected', (event, data) => callback(data)),
  onBypassProgress: (callback) =>
    ipcRenderer.on('bypass-progress', (event, data) => callback(data)),
});
