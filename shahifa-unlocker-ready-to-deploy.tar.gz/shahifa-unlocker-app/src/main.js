const { app, BrowserWindow, Menu, ipcMain, dialog } = require('electron');
const path = require('path');
const isDev = require('electron-is-dev');
const axios = require('axios');
const fs = require('fs');

let mainWindow;
let authToken = null;
let currentUser = null;

const API_BASE_URL = 'https://shahifa.com/api';
const STORE_PATH = path.join(app.getPath('userData'), 'store.json');

// Load stored data
function loadStore() {
  try {
    if (fs.existsSync(STORE_PATH)) {
      return JSON.parse(fs.readFileSync(STORE_PATH, 'utf-8'));
    }
  } catch (err) {
    console.error('Error loading store:', err);
  }
  return { token: null, user: null };
}

// Save data to store
function saveStore(data) {
  try {
    fs.writeFileSync(STORE_PATH, JSON.stringify(data, null, 2));
  } catch (err) {
    console.error('Error saving store:', err);
  }
}

// Create main window
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 1024,
    minHeight: 600,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      enableRemoteModule: false,
      nodeIntegration: false,
    },
    icon: path.join(__dirname, '../assets/icons/icon.png'),
  });

  const startUrl = isDev
    ? 'http://localhost:3000'
    : `file://${path.join(__dirname, '../public/index.html')}`;

  mainWindow.loadURL(startUrl);

  if (isDev) {
    mainWindow.webContents.openDevTools();
  }

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

// API calls
async function apiCall(method, endpoint, data = null, token = authToken) {
  try {
    const config = {
      method,
      url: `${API_BASE_URL}${endpoint}`,
      headers: {
        'Content-Type': 'application/json',
      },
    };

    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }

    if (data && (method === 'POST' || method === 'PUT')) {
      config.data = data;
    }

    const response = await axios(config);
    return { success: true, data: response.data };
  } catch (error) {
    return {
      success: false,
      error: error.response?.data?.error || error.message,
    };
  }
}

// IPC Handlers
ipcMain.handle('login', async (event, { username, password, mfaCode }) => {
  const result = await apiCall('POST', '/auth/login', {
    username,
    password,
    mfaCode,
  }, null);

  if (result.success) {
    authToken = result.data.accessToken;
    currentUser = result.data.user;
    saveStore({ token: result.data.refreshToken, user: currentUser });
  }

  return result;
});

ipcMain.handle('logout', async (event) => {
  if (authToken) {
    await apiCall('POST', '/auth/logout', {});
  }
  authToken = null;
  currentUser = null;
  saveStore({ token: null, user: null });
  return { success: true };
});

ipcMain.handle('get-user', () => {
  return { success: true, user: currentUser };
});

ipcMain.handle('get-wallet', async () => {
  return apiCall('GET', '/my-wallet', null);
});

ipcMain.handle('get-subscription', async () => {
  return apiCall('GET', '/my-subscription', null);
});

ipcMain.handle('get-subscription-plans', async () => {
  return apiCall('GET', '/subscription-plans', null);
});

ipcMain.handle('start-device-detection', async () => {
  // This would integrate with actual USB device detection
  return {
    success: true,
    data: {
      devices: [],
      status: 'scanning',
    },
  };
});

ipcMain.handle('execute-bypass', async (event, { deviceId, method }) => {
  return {
    success: true,
    data: {
      operationId: `op_${Date.now()}`,
      status: 'in_progress',
      device: deviceId,
      method,
    },
  };
});

// App event handlers
app.on('ready', () => {
  createWindow();

  // Load stored token if available
  const store = loadStore();
  if (store.token) {
    authToken = store.token;
    currentUser = store.user;
  }

  createApplicationMenu();
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (mainWindow === null) {
    createWindow();
  }
});

// Application menu
function createApplicationMenu() {
  const template = [
    {
      label: 'Shahifa Unlocker',
      submenu: [
        { role: 'about' },
        { type: 'separator' },
        { role: 'quit' },
      ],
    },
    {
      label: 'Edit',
      submenu: [
        { role: 'undo' },
        { role: 'redo' },
        { type: 'separator' },
        { role: 'cut' },
        { role: 'copy' },
        { role: 'paste' },
      ],
    },
    {
      label: 'View',
      submenu: [
        { role: 'reload' },
        { role: 'forceReload' },
        { role: 'toggleDevTools' },
        { type: 'separator' },
        { role: 'resetZoom' },
        { role: 'zoomIn' },
        { role: 'zoomOut' },
        { type: 'separator' },
        { role: 'togglefullscreen' },
      ],
    },
    {
      label: 'Help',
      submenu: [
        {
          label: 'Documentation',
          click: () => {
            // Open documentation
          },
        },
        {
          label: 'Support',
          click: () => {
            // Open support
          },
        },
      ],
    },
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
}
